
# FraudShield AI
AI-Powered Financial Transaction Fraud Detection

## Features
- Transaction fraud classification
- Fraud risk score
- Random Forest machine learning model
- Interactive transaction testing
- Analytics dashboard

## Technology
Python, Pandas, NumPy, Scikit-learn, Plotly

## Dataset
Indian Banking Transactions dataset.
Dataset records may be simulated; this is a prototype,
not a production banking fraud detection system.

## Run
Open FraudShield_AI.ipynb in Google Colab and run cells.

## Model
fraud_model.pkl
